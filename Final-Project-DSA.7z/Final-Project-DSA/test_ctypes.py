from ctypes import cast, POINTER
print("ctypes imported successfully!")
