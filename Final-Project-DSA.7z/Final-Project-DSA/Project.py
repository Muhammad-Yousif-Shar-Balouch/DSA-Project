import cv2
import mediapipe as mp
from math import hypot
import screen_brightness_control as sbc
import numpy as np
import webbrowser
from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume
from ctypes import cast, POINTER
from comtypes import CLSCTX_ALL
from scipy.spatial.distance import euclidean
from collections import deque

# Initialize MediaPipe Hands
mpHands = mp.solutions.hands
hands = mpHands.Hands(
    static_image_mode=False,
    model_complexity=1,
    min_detection_confidence=0.75,
    min_tracking_confidence=0.75,
    max_num_hands=2
)
Draw = mp.solutions.drawing_utils

# Pycaw setup for volume control
devices = AudioUtilities.GetSpeakers()
interface = devices.Activate(IAudioEndpointVolume._iid_, CLSCTX_ALL, None)
volume_control = cast(interface, POINTER(IAudioEndpointVolume))

# Start capturing video from the webcam
cap = cv2.VideoCapture(0)

# Initialize control variables
brightness = 50
volume = 50
zoom = 100
website_opened = False  # To prevent repeated website opening

# Stack to track gestures
gesture_stack = deque(maxlen=10)  # Track recent gestures

# Random website list
websites = ["https://www.google.com", "https://www.github.com", "https://www.wikipedia.org"]

# Function to open a random website
def open_random_website():
    global website_opened
    if not website_opened:
        webbrowser.open(np.random.choice(websites))
        website_opened = True  # Set to true to avoid repeated opening

# Function to reset website_opened flag
def reset_website_opened():
    global website_opened
    website_opened = False

# Core loop for frame capture and gesture recognition
while True:
    _, frame = cap.read()

    # Flip the image horizontally for mirror effect
    frame = cv2.flip(frame, 1)

    # Convert the image to RGB format
    frameRGB = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    Process = hands.process(frameRGB)

    landmarkList = []

    # If hands are detected
    if Process.multi_hand_landmarks:
        for handlm in Process.multi_hand_landmarks:
            for _id, landmarks in enumerate(handlm.landmark):
                height, width, color_channels = frame.shape
                x, y = int(landmarks.x * width), int(landmarks.y * height)
                landmarkList.append([_id, x, y])

            # Draw the landmarks
            Draw.draw_landmarks(frame, handlm, mpHands.HAND_CONNECTIONS)

    if landmarkList:
        # Get positions for gesture analysis (thumb, pinky, etc.)
        x_thumb, y_thumb = landmarkList[4][1], landmarkList[4][2]
        x_pinky, y_pinky = landmarkList[20][1], landmarkList[20][2]

        # Brightness adjustment
        x_index, y_index = landmarkList[8][1], landmarkList[8][2]
        distance_index_thumb = euclidean((x_index, y_index), (x_thumb, y_thumb))
        new_brightness = np.interp(distance_index_thumb, [15, 220], [0, 100])
        if abs(new_brightness - brightness) > 1:
            brightness = int(new_brightness)
            sbc.set_brightness(brightness)

        # Volume adjustment using pycaw
        x_middle, y_middle = landmarkList[12][1], landmarkList[12][2]
        distance_middle_thumb = euclidean((x_middle, y_middle), (x_thumb, y_thumb))
        volume_level = np.interp(distance_middle_thumb, [15, 220], [-65, 0])  # Volume range
        volume_control.SetMasterVolumeLevel(volume_level, None)

        # Zoom adjustment
        x_ring, y_ring = landmarkList[16][1], landmarkList[16][2]
        distance_ring_thumb = euclidean((x_ring, y_ring), (x_thumb, y_thumb))
        new_zoom = np.interp(distance_ring_thumb, [15, 220], [50, 200])
        if abs(new_zoom - zoom) > 1:
            zoom = int(new_zoom)

        # Check if pinky touches the thumb
        distance_pinky_thumb = euclidean((x_pinky, y_pinky), (x_thumb, y_thumb))
        if distance_pinky_thumb < 30:  # Adjust threshold as needed
            open_random_website()
            gesture_stack.append("Thumb-Pinky Touch")
        else:
            reset_website_opened()  # Reset the flag when fingers are apart

        # Draw lines for gesture feedback
        cv2.line(frame, (x_thumb, y_thumb), (x_index, y_index), (0, 255, 0), 2)  # Brightness
        cv2.line(frame, (x_thumb, y_thumb), (x_middle, y_middle), (0, 255, 255), 2)  # Volume
        cv2.line(frame, (x_thumb, y_thumb), (x_ring, y_ring), (255, 0, 0), 2)  # Zoom

        # Display the current status
        cv2.putText(frame, f'Brightness: {brightness}%', (10, 40), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2)
        cv2.putText(frame, f'Volume: {volume_control.GetMasterVolumeLevelScalar()*100:.0f}%', (10, 80), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2)
        cv2.putText(frame, f'Zoom: {zoom}%', (10, 120), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2)

        # Display recent gestures using the stack
        if gesture_stack:
            recent_gestures = ', '.join(gesture_stack)
            cv2.putText(frame, f'Gestures: {recent_gestures}', (10, 160), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 255), 2)

    # Apply zoom effect by cropping and resizing
    zoom_factor = zoom / 100
    centerX, centerY = frame.shape[1] // 2, frame.shape[0] // 2
    radiusX, radiusY = int(centerX / zoom_factor), int(centerY / zoom_factor)

    minX, maxX = max(0, centerX - radiusX), min(frame.shape[1], centerX + radiusX)
    minY, maxY = max(0, centerY - radiusY), min(frame.shape[0], centerY + radiusY)

    cropped_frame = frame[minY:maxY, minX:maxX]
    frame = cv2.resize(cropped_frame, (frame.shape[1], frame.shape[0]))

    # Show the current frame
    cv2.imshow("Hand Gesture Control", frame)

    # Handle keypresses
    key = cv2.waitKey(1) & 0xFF

    # Exit the program (press 'q')
    if key == ord('q'):
        break

# Release the video capture and close all windows
cap.release()
cv2.destroyAllWindows()
